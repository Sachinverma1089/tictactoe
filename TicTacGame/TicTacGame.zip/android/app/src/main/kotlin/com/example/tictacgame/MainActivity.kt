package com.example.tictacgame

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
